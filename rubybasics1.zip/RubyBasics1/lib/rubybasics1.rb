# Lab 1
# Part I
def sum arr
  # YOUR CODE HERE
end

# Part II
def max_2_sum arr
  # YOUR CODE HERE
end

# Part III
def sum_to_n? arr, n
  # YOUR CODE HERE
end